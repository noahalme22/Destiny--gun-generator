import random, secondary

class fusion(secondary.secondary)

if fusion == "":
  fusion = random.randint(1,6)
  fusion  = random.choice(["Telesto","Merciless","Plan C","Saladins Vigil","Tarantula","Main Ingredient"])

