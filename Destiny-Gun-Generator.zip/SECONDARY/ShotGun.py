import random, secondary

class shotgun(secondary.secondary)

if shotgun == "":
  shotgun = random.randint(1,6)
  shotgun  = random.choice(["Matador 64","Party Crasher +1","Universal Remote","Hawthorne's Field-Forged Shotgun","Gunnora's Axe","Legend of Acrius"])
