import random, secondary

class sniper(secondary.secondary)

if sniper == "":
  sniper = random.randint(1,6)
  sniper  = random.choice(["Ice Breaker","Longbow Synthesis","LDR 5001","D.A.R.C.I","Aachen-LR2","Borealis"])


