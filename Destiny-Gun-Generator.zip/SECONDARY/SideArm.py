import random, secondary

class sidearm(secondary.secondary)

if sidearm == "":
  sidearm = random.randint(1,6)
  sidearm  = random.choice(["Wormwood","Tresspasser","Havoc Pigeon","Last Hope","The Last Dance","Rat King"])

