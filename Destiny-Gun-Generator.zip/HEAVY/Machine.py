import random, heavy

class machineGun(heavy.heavy):

	if machine == "":
			machineRan = random.randint(1,3)
			machinee = random.choice(["ThunderLord","The Culling","Zombie Apocalypse WF47"])
