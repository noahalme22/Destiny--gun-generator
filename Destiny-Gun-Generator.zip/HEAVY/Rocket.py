import random,heavy

class rocketLauncher(heavy.heavy):

	if rocket == "":
				rocketRan = random.randint(1,6)
				rocket = random.choice(["Gjallarhorn","Dragons Breath","Suros JLB-47","Curtain Call","Warcliff coil","Sins Of The Past"])
