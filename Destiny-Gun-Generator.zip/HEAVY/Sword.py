import random,heavy

class swords(heavy.heavy):

	if sword == "":
				swordRan = random.randint(1,4)
				swordRan= random.choice(["Raze-Lighter","Dark-Drinker","The Young Wolfs Howl","Worldline Zero"])
