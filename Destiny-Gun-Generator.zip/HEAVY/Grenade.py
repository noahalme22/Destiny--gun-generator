import heavy,random

class grandeLauncher(heavy.heavy):

	if grenade == "":
		grenadeRan = random.randint(1,3)
		grenade= random.choice(["Play of the game","the colony","I Am Alive"])
