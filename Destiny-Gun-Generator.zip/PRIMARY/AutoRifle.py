import random,primary


class AutoRifle(primary.primary):

	if autoRifle == "":
				autoRan = random.randint(1,6)
				autoRifle = random.choice(["Uriels Gift","doctrine of passing","Monte Carlo","origin Story","Zhalo Supercell","Kibou AR3"])
