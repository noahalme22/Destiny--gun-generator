import random,primary


class HandCannon(primary.primary):

	if handCannon == "":
				HCRan = random.randint(1,6)
				handCannon = random.choice(["Crimson","Palindrome","Eyesluna","Last Word","Better Devils","Old Fashioned"])
				
