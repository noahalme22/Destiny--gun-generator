#Noah ALmeida / Xavier Langavin
#25/05/2018
#Destiny Gun Generator

import random,prototype
class primary(prototype.prototype):
	'''primary weapon generator'''

	def __init__(self,gunType2="", autoRifle = "", scoutRifle = "", pulseRifle = "", handCannon = "", smg = ""):

			if gunType2 == "primary":
				typeRan2 = random.randint(1,5)
			
				if typeRan2 == 1:
					gunType2 = autoRifle
					
				elif typeRan2 == 2:
					gunType2 = scoutRifle
					
				elif typeRan2 == 3:
					gunType2 = pulseRifle

				elif typeRan2 == 4:
					gunType2 = handCannon
					
				elif typeRan2 == 5:
					gunType2 = smg
				
				
			
			self.gunType2 = gunType2
			self.auto = autoRifle
			self.pulse = pulseRifle
			self.scout = scoutRifle
			self.smg = smg	
			self.handCannon = handCannon
			
			
							
							

			
