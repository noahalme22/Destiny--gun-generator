import random,primary

class PulseRifle(primary.primary):

	if pulseRifle == "":
				pulseRan = random.randint(1,6)
				pulseRifle = random.choice(["Grasp of Malok","Blind Predicion","vigilance wing","nightshade","red death","Graviton Lance"])
