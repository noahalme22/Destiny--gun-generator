import random,primary

class ScoutRifle(primary.primary):

	if scoutRifle == "":
				scoutRan = random.randint(1,6)
				scoutRifle = random.choice(["Mida Multi tool","Nameless Midnight","Jade Rabbit","the burning eye","BrayTech RWP MK. II","((CHAOS DOGMA~))"])
