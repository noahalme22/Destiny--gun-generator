import random,primary

class SMG(primary.primary):

	if smg == "":
				smgRan = random.randint(1,3)
				smg = random.choice(["Antiope-D","Adjudicator","Risk Runner"])
